"""
===========================
Magic angle turning example
===========================

.. image:: MAT_pulse_sequence.PNG

.. image:: ../../figures/MAT_phase_cycle.PNG
"""

from matplotlib import pyplot as plt
import numpy as np

if __name__ == "__main__":

    plt.plot([1,2,3],[4,5,6])

